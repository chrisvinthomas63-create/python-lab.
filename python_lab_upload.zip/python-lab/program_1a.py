print("Welcome to Python Programming!")
print("My name is Dhruti")
print("Python is easy to learn.")
