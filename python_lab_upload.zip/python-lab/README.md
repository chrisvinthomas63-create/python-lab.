# Python Programming Lab

This folder contains the 20 Python programs transcribed from the uploaded
30-page Python Programming Lab Report.

## Programs

| File | Program |
|---|---|
| program_1a.py | Basic Python Program |
| program_1b.py | Arithmetic Operations Using Variables |
| program_1c.py | Calculator |
| program_1d.py | Celsius to Fahrenheit Converter |
| program_2a.py | Number Guessing Game |
| program_2b.py | Prime Number and Factorial |
| program_2c.py | Fibonacci Series Using Recursion |
| program_2d.py | Random 6-Digit OTP |
| program_3a.py | Contact Book |
| program_3b.py | Student Grade Based on Marks |
| program_3c.py | Frequency of Elements in a List |
| program_3d.py | Student Attendance Management System |
| program_4a.py | Read and Display Log File |
| program_4b.py | Student Details Using Files |
| program_4c.py | Employee Salary Using CSV |
| program_4d.py | System Logs Using JSON |
| program_5a.py | Bank Account Using Classes and Objects |
| program_5b.py | Manage Books Using Classes and Objects |
| program_5c.py | Simulate Rolling a Dice |
| program_5d.py | Retail Sales Analysis and Bar Chart |

## Run a program

Open a terminal in this folder and run:

```bash
python program_1a.py
```

Change the filename to run another program.

## Additional dependency

Program `program_5d.py` uses Matplotlib. Install it with:

```bash
pip install matplotlib
```

Note: The programs are transcribed from the PDF. The PDF's example names
(e.g. Dhruti) have been kept as written.
