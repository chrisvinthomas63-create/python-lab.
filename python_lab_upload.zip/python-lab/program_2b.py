n = int(input("Enter a number: "))

# Prime number
if n > 1:
    for i in range(2, n):
        if n % i == 0:
            print("Not a Prime Number")
            break
    else:
        print("Prime Number")
else:
    print("Not a Prime Number")

# Factorial
fact = 1
for i in range(1, n + 1):
    fact = fact * i

print("Factorial:", fact)
