import random

number = random.randint(1, 10)
guess = int(input("Guess a number between 1 and 10: "))

if guess == number:
    print("Congratulations! Correct guess.")
else:
    print("Wrong guess!")
    print("The correct number was:", number)
